﻿namespace Sonovate.Domain.Enums
{
    public enum BacsExportType
    {
        None, Agency, Supplier 
    }
}