﻿namespace Sonovate.Domain.Enums
{
    public enum Participant
    {
        Candidate,
        Agency
    }
}