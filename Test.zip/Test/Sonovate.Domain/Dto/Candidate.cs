﻿using Sonovate.Domain.Entities;

namespace Sonovate.Domain.Dto
{
    public class Candidate
    {
        public BankDetails BankDetails { get; set; }
    }
}