﻿using Sonovate.Domain.Entities;
using System.Collections.Generic;

namespace Sonovate.Domain.Dto
{
    public class SupplierBacsExport
    {
        public IEnumerable<SupplierBacs> SupplierPayment { get; set; }
    }
}