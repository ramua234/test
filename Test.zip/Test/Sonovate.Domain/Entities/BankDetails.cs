﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sonovate.Domain.Entities
{
    public class BankDetails
    {
        public string AccountNumber { get; set; }
        public string AccountName { get; set; }
        public string SortCode { get; set; }
    }

}
