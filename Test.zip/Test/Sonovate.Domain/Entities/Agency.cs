﻿using Sonovate.Domain.Entities;

namespace Sonovate.Domain.Entities
{
    public class Agency
    {
        public string Id { get; set; }
        public BankDetails BankDetails { get; set; }
    }
}