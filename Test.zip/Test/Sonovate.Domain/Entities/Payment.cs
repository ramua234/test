﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sonovate.Domain.Entities
{
    public class Payment
    {
        public string AgencyId { get; set; }
        public decimal Balance { get; set; }
        public DateTime PaymentDate { get; set; }
    }
}
