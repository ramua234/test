﻿namespace Sonovate.Domain
{
    public class BankDetails
    {
        public string AccountNumber { get; set; }
        public string AccountName { get; set; }
        public string SortCode { get; set; }
    }
}