﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

using CsvHelper;
using Raven.Client.Documents;
using Sonovate.Repositories;
using Sonovate.Domain.Entities;
using Sonovate.Domain.Dto;
using Sonovate.Domain.Enums;

namespace Sonovate.CodeTest
{
    public class BacsExportService
    {
        private const string NOT_AVAILABLE = "NOT AVAILABLE";

        private IDocumentStore documentStore;

        public BacsExportService()
        {
            documentStore = new DocumentStore { Urls = new[] { "http://localhost" }, Database = "Export" };
            documentStore.Initialize();
        }

        public async Task ExportZip(BacsExportType bacsExportType)
        {
            if (bacsExportType == BacsExportType.None)
            {
                const string invalidExportTypeMessage = "No export type provided.";
                throw new Exception(invalidExportTypeMessage);
            }

            var startDate = DateTime.Now.AddMonths(-1);
            var endDate = DateTime.Now;

            try
            {
                switch (bacsExportType)
                {
                    case BacsExportType.Agency:
                        if (IsAgencyPaymentsEnabled)
                        {
                            var payments = await GetAgencyPayments(startDate, endDate);
                            SavePayments(payments, bacsExportType);
                        }
                        break;

                    case BacsExportType.Supplier:
                        var supplierBacsExport = GetSupplierPayments(startDate, endDate);
                        SaveSupplierBacsExport(supplierBacsExport);
                        break;

                    default:
                        throw new Exception("Invalid BACS Export Type.");
                }

            }
            catch (InvalidOperationException inOpEx)
            {
                throw new Exception(inOpEx.Message);
            }
        }

        private bool IsAgencyPaymentsEnabled
        {
            get
            {
                return Application.Settings["EnableAgencyPayments"] == "True";
            }
        }

        private async Task<IEnumerable<BacsResult>> GetAgencyPayments(DateTime startDate, DateTime endDate)
        {
            var paymentRepository = new PaymentsRepository();

            var payments = paymentRepository.GetBetweenDates(startDate, endDate);

            if (!payments.Any())
            {
                throw new InvalidOperationException($"No agency payments found between dates {startDate} to {endDate}");
            }

            var agencies = await GetAgenciesForPayments(payments);

            return BuildAgencyPayments(payments, agencies);
        }

        private async Task<IEnumerable<Agency>> GetAgenciesForPayments(IList<Payment> payments)
        {
            var agencyIds = payments.Select(x => x.AgencyId).Distinct();

            using (var session = documentStore.OpenAsyncSession())
            {
                return (await session.LoadAsync<Agency>(agencyIds)).Values;
            }
        }

        private IEnumerable<BacsResult> BuildAgencyPayments(IEnumerable<Payment> payments, IEnumerable<Agency> agencies)
        {
            return (from p in payments
                    let agency = agencies.FirstOrDefault(x => x.Id == p.AgencyId)
                    where agency != null && agency.BankDetails != null
                    let bank = agency.BankDetails
                    select new BacsResult
                    {
                        AccountName = bank.AccountName,
                        AccountNumber = bank.AccountNumber,
                        SortCode = bank.SortCode,
                        Amount = p.Balance,
                        Ref = string.Format("SONOVATE{0}", p.PaymentDate.ToString("ddMMyyyy"))
                    }).AsEnumerable();
        }

        private void SavePayments(IEnumerable<BacsResult> payments, BacsExportType type)
        {
            WriteRecords(payments, $"{type}_BACSExport.csv");
        }

        private SupplierBacsExport GetSupplierPayments(DateTime startDate, DateTime endDate)
        {
            var invoiceTransactions = new InvoiceTransactionRepository();

            var candidateInvoiceTransactions = invoiceTransactions.GetBetweenDates(startDate, endDate);

            if (!candidateInvoiceTransactions.Any())
            {
                throw new InvalidOperationException($"No supplier invoice transactions found between dates {startDate} to {endDate}");
            }

            return CreateCandidateBacxExportFromSupplierPayments(candidateInvoiceTransactions);
        }
        private SupplierBacsExport CreateCandidateBacxExportFromSupplierPayments(IList<InvoiceTransaction> supplierPayments)
        {
            return new SupplierBacsExport
            {
                SupplierPayment = BuildSupplierPayments(supplierPayments)
            };
        }

        private List<SupplierBacs> BuildSupplierPayments(IEnumerable<InvoiceTransaction> invoiceTransactions)
        {
            var candidateRepository = new CandidateRepository();
            var results = new List<SupplierBacs>();

            var transactionsByCandidateAndInvoiceId = invoiceTransactions
                .GroupBy(transaction => new
                {
                    transaction.InvoiceId,
                    transaction.SupplierId
                });

            foreach (var transactionGroup in transactionsByCandidateAndInvoiceId)
            {
                var candidate = candidateRepository.GetById(transactionGroup.Key.SupplierId);

                if (candidate == null)
                {
                    throw new InvalidOperationException($"Could not load candidate with Id {transactionGroup.Key.SupplierId}");
                }
                
                var bank = candidate.BankDetails;

                var result = new SupplierBacs
                {
                    AccountName = bank.AccountName,
                    AccountNumber = bank.AccountNumber,
                    SortCode = bank.SortCode,
                    PaymentAmount = transactionGroup.Sum(invoiceTransaction => invoiceTransaction.Gross),
                    InvoiceReference = string.IsNullOrEmpty(transactionGroup.First().InvoiceRef) ? NOT_AVAILABLE : transactionGroup.First().InvoiceRef,
                    PaymentReference = $"SONOVATE{transactionGroup.First().InvoiceDate.GetValueOrDefault().ToString("ddMMyyyy")}"
                };

                results.Add(result);
            }

            return results;
        }

        private void SaveSupplierBacsExport(SupplierBacsExport supplierBacsExport)
        {
            WriteRecords(supplierBacsExport.SupplierPayment, $"{BacsExportType.Supplier}_BACSExport.csv");
        }

        private void WriteRecords<T>(IEnumerable<T> items, string fileName) where T : class
        {
            using (var csv = new CsvWriter(new StreamWriter(new FileStream(fileName, FileMode.Create))))
            {
                csv.WriteRecords(items);
            }
        }
    }
}