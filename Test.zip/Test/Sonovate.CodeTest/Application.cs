﻿using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using Sonovate.Domain.Enums;

namespace Sonovate.CodeTest
{
    public static class Application
    {
        public static void Main()
        {
            var builder = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string>
            {
                { "EnableAgencyPayments", "True" }
            });

            Settings = builder.Build();

            new BacsExportService().ExportZip(BacsExportType.Supplier).Wait();
        }

        public static IConfigurationRoot Settings { get; private set; }
    }
}
